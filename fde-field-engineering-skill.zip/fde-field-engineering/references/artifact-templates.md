# FDE Artifact Templates

Adapt these to the repository, customer, contract, and risk track. Omit sections that add no value; retain IDs and decision history when work spans people or sessions. Do not include secrets, raw customer records, or unnecessary personal data in project documentation.

## Opportunity brief

```markdown
# Opportunity: <name>
Status: explore | pursue | hold | decline
Track: quick | standard | high-governance
Sponsor / business owner: <name or role>
Users and affected teams: <who>

## Stated request
<What the customer asked for, without assuming it is the real problem>

## Workflow problem
<Who does what, where it gets stuck, frequency/impact, current workaround>
Evidence: <observation / sample / customer claim / hypothesis>

## Business case
Baseline: <metric, current value, source, window>
Intended outcome: <target or decision threshold and owner>
Priority and why now: <business sponsor confirmation>

## Constraints and unknowns
Data / systems / permissions: <knowns and gaps>
Security, privacy, compliance, IP: <reviewers and boundary>
User readiness / process change: <knowns and gaps>

## First evidence slice
<Smallest reversible action that tests value or feasibility>
Success / stop condition: <observable condition>
Decision: <pursue / hold / decline, rationale, next owner/date>
```

## Discovery record

```markdown
# Discovery: <workflow>
Participants / roles: <...>
Observed date and source: <...>

Trigger → Inputs → Steps → Decisions → Handoffs → Output → Exception/human takeover
Systems and source-of-truth fields: <...>
Business objects, relationships, states, allowed actions: <only what is evidenced>
Volume / cycle time / errors / rework / cost / service level: <baseline and source>
Current user pain and workaround: <...>
Risky or disallowed actions: <...>
Assumptions / facts / unknowns: <label each>
Open questions and owner: <...>
```

## Engagement brief and decision log

```markdown
# Engagement brief: <name>
Problem and user: <...>
Outcome metric + baseline + owner + observation window: <...>
Scope: <workflow/users/systems>
Non-goals / remain-human steps: <...>
First thin slice: <...>
Acceptance criteria: <observable, testable checks>
Data and authorization boundary: <...>
Risks / controls / fallback: <...>
Dependencies / owners: <...>
Decision gate: <continue / narrow / stop and what evidence decides>

## Decisions
| ID | Decision and date | Options / reason | Owner | Revisit trigger |
|---|---|---|---|---|
| D-01 | <...> | <...> | <...> | <...> |
```

## Architecture and safety note

```markdown
# Solution note: <name>
Workflow and maturity target: <L0–L4 / why>
Current systems and data flow: <...>
Components / model / Skills / connectors: <...>
Business objects, state transitions, actions: <...>
Identity, scopes, storage, retention, tenancy: <...>
External side effects and approval rules: <...>
Deterministic checks / human review / escalation: <...>
Timeouts, retries, idempotency, safe failure: <...>
Observability and audit: <...>
Evaluation data, expected behavior, adjudicator: <...>
Rollback / disable procedure: <...>
Known limits and rejected alternatives: <...>
```

## Vertical slice / story

```markdown
## <ID> — <user-visible outcome>
User and context: <...>
Behavior: <Given / When / Then or equivalent>
Acceptance checks: <observable, testable criteria>
Systems / data / permissions: <...>
Evaluation cases: <IDs or examples>
Risk / human fallback: <...>
Telemetry / owner: <...>
Dependencies: <...>
Rollback or disable: <...>
```

## Evaluation record

```markdown
# Evaluation: <build/version/date>
Scope and risk level: <...>
Baseline / comparator: <...>
Dataset provenance and authorization: <approved / synthetic; no raw sensitive data>
| Case ID | Scenario and expected behavior | Actual | Severity | Pass? | Follow-up |
|---|---|---|---|---|---|
| E-01 | <...> | <...> | <...> | <...> | <...> |

Summary: task success <...>; error/override <...>; latency/cost <...>
Business comparison: <baseline vs pilot, limitations>
Human review / exception results: <...>
Decision: <iterate / pilot / production gate / stop>
Approver and evidence: <...>
```

## Production and adoption handoff

```markdown
# Launch / handoff: <capability>
Maturity and approved scope: <...>
Business owner / run owner / support contact: <...>
User group / training / workflow location: <...>
Data, access, security, privacy, compliance sign-off: <...>
Evaluation version and accepted limitations: <...>
Monitoring / alerts / service expectations: <...>
Human override / incident / rollback path: <...>
Baseline and post-launch review date: <...>
Runbook / documentation / access transfer: <...>
Customer-owned items / provider-owned generic items: <...>
Open issues and owners: <...>
```

## Field-learning / reusable-asset proposal

```markdown
# Field learning: <title>
Originating engagement: <internal reference only>
Discovery: <pattern observed; avoid customer identifiers>
Current reusable asset/version: <...>
Gap and proposed generalization: <...>
Evidence from distinct workflows/engagements: <...>
Generality confidence: high | medium | low; why: <...>
Customer-specific elements excluded: <data, parameters, code, context>
Data/IP/consent review: <owner and status>
Proposed asset type: Skill | connector | template | eval | product issue | domain model
Acceptance/regression cases: <...>
Owner / version / review date: <...>
Decision: reusable now | gather evidence | customer-specific | do not retain
```

## Retrospective

```markdown
# FDE retrospective: <increment/date>
Business outcome vs baseline: <...>
User adoption and operational health: <...>
What surprised us / what failed: <evidence, not blame>
Which assumption changed: <...>
What can safely be reused and what must stay customer-specific: <...>
Did similar work take less effort? <compare like-for-like; explain limits>
One process, product, asset, or decision rule to change: <owner/date>
Next decision: expand | maintain | revise | retire
```
