# FDE Workflow and Gates

Use this as an adaptive playbook, not a rigid waterfall. Revisit earlier decisions when customer evidence changes. Keep only the artifacts needed to make work understandable, testable, safe, and reusable.

## Choose the delivery track

| Track | Use when | Minimum control |
|---|---|---|
| Quick field loop | One contained workflow, known owner, low-impact changes, reversible prototype, clear success signal | Brief, one thin slice, representative checks, demo/decision, short learning note |
| Standard engagement | A real team workflow, a few systems or roles, data preparation, and controlled pilot | Discovery brief, lightweight requirements and architecture, phased slices, evaluation set, pilot and launch checks |
| High-governance program | Regulated/sensitive data, consequential actions, many teams/integrations, material org change, or unclear ownership | Named sponsor and control owners, risk review, privacy/security/compliance gates, decisions, staged approvals, production operations and rollback |

The track describes the controls needed for the current phase; it is not a commitment to run the whole engagement at that level. Reassess at every gate. High-uncertainty intake may need cautious discovery while the eventual bounded pilot remains lightweight. Raise the track when impact or uncertainty rises; lower it only when scope, data, and consequences are demonstrably bounded. A simple FAQ or summarization task may need no FDE-heavy build if a standard product or existing workflow already solves it.

## Stage 0 — Intake and fit

**Purpose:** Decide whether the engagement merits front-line discovery and how much structure it needs.

- Capture the customer's stated request without assuming it is the underlying problem.
- Identify the executive sponsor, accountable business owner, affected users, IT/system owner, and any security/privacy/compliance owner.
- Check whether the use case has a real owner and adoption path. Ask whether it is a leadership or business priority, not only an attractive demo.
- Assess whether workflows repeat across similar users/customers and whether the learning could reduce future effort. Heavy FDE is a poor fit for low-impact, one-off work with no reuse path unless bespoke work is explicitly funded.
- Decide `pursue`, `hold`, or `decline`, record why, and identify the next smallest evidence-gathering step.

**Gate:** Do not promise production delivery until a business owner, a testable outcome, a feasible data/system path, and the appropriate decision-makers are identified. Missing evidence means `hold`, not an invented commitment.

## Stage 1 — Discover the real work

**Echo leads; Delta and the domain/customer team participate.** Observe or walk through the real task with operators. Capture the current path, variants, exceptions, handoffs, rework, and informal workarounds. Do not start by writing prompts or choosing an agent architecture.

Establish:

- Who performs the task, who receives the result, who can approve it, and who owns the business outcome.
- How the workflow starts and ends; inputs, outputs, systems, permissions, source-of-truth data, and exception paths.
- Current volume, cycle time, error/rework rate, service level, cost, or other relevant baseline.
- What “better” means, how it will be measured, and over what observation window.
- Constraints: data location/retention, privacy, IP, regulation, model availability, latency/cost, accessibility, procurement, network isolation, and change management.
- Whether probabilistic automation is appropriate, where deterministic rules are safer, and where a person must review, approve, or take over.

Use interviews, observation, process maps, samples, and authorized system evidence. Label statements as observed facts, customer claims, hypotheses, or unknowns. Use approved, minimized, or synthetic examples for early prototypes when possible.

**Gate:** The team can state the business problem, current baseline, affected users, decision owner, and a falsifiable success hypothesis. Otherwise continue discovery or stop.

## Stage 2 — Frame the outcome and first slice

Write a concise engagement brief that separates the problem from the proposed solution:

1. Problem and affected user in the customer's operational context.
2. Current workflow and measurable baseline; intended outcome and measurement owner.
3. In-scope workflow and explicit non-goals, including what remains human-led.
4. Data/integration assumptions, authorization boundary, risk, and known unknowns.
5. First thin, reversible slice that tests the riskiest value or feasibility assumption.
6. Acceptance criteria, pilot population, decision condition, and stop/continue rule.

Prioritize by business value, feasibility, user readiness, risk, and likelihood of reuse. Avoid a long feature wish list. If baselines cannot be measured, define a short measurement phase before claiming impact. The first evidence slice may be a no-code workflow walkthrough, sample review, or metric-baseline exercise; it need not be a prototype.

**Gate:** The business owner agrees what success and failure look like; the technical owner confirms a feasible first slice; affected users and control owners know what is being tested. A discovery exercise alone does not advance the project to L1 prototype maturity.

## Stage 3 — Shape the solution and plan the work

Delta leads technical shaping with Echo, FDPM, the customer system owner, and product/platform support.

- Map the current and target workflow. Identify business objects, relationships, states, allowed actions, and exceptions only to the level the use case requires.
- Select the smallest suitable product, model, workflow, connector, Skill, or custom component. Prefer configuration and reviewed reusable assets; do not create a full ontology before evidence justifies it.
- Define system boundaries: data sources/flows, identity, least-privilege scopes, tenancy, storage/retention, logs, external side effects, and customer-owned versus provider-owned assets.
- Specify agent behavior, deterministic rules, tool calls, timeouts, retries, idempotency where relevant, human review/escalation, and safe failure behavior.
- Define evaluation before build: representative happy paths, edge cases, disallowed requests/actions, authorized historical or synthetic examples, expected behavior, severity, and adjudicator.
- Record key decisions and rejected alternatives briefly. Split work into small, independently verifiable vertical slices with clear dependencies and owners.

**Gate:** Explain the solution in business terms and trace it to the outcome. Understand data use, action authority, evaluation, fallback, and acceptance before sensitive or consequential implementation begins.

## Stage 4 — Co-build in short field iterations

For each slice:

1. Restate the user, workflow step, intended behavior, and acceptance checks.
2. Inspect existing code, platform capabilities, connectors, patterns, and customer constraints before changing anything.
3. Build the smallest end-to-end path that can be demonstrated and evaluated. AI coding tools accelerate execution; they do not waive architecture, privacy, review, or tests.
4. Test with representative approved cases, inspect failures, and include a relevant edge or negative case. Keep failing cases as regression examples where permitted.
5. Review against acceptance, safety boundaries, and customer workflow. Record evidence and remaining gaps before taking the next slice.
6. Demonstrate with intended users and capture what changed in their understanding or behavior.

Keep customer-specific code/configuration separate from reusable product assets. A rough prototype is acceptable only in a bounded, non-production setting; label it clearly and do not imply operational readiness.

**Gate:** Acceptance evidence is visible, material failures are understood, and the next slice is justified by value and learning. Otherwise revise, narrow, hold, or stop.

## Stage 5 — Evaluate and graduate toward production

Use maturity labels as a conversation aid. Progress is evidence-based; labels do not prescribe duration.

| Level | Meaning | Evidence to advance |
|---|---|---|
| L0 — Opportunity | Workflow and value hypothesis identified | Owner, baseline plan, feasibility questions, risk boundary |
| L1 — Runnable prototype | Core path works in a controlled demo | Representative scenarios, known limits; no production-readiness claim |
| L2 — Limited pilot | Intended users try it in a bounded real workflow | Approved data/access, user feedback, eval results, human fallback |
| L3 — Production | Capability is embedded in an owned business process | Applicable security/privacy/compliance sign-off, monitoring, audit, support owner, service targets, incident/rollback plan, training, tested exceptions |
| L4 — Scale | Safe expansion across users, workflows, or partners/customers | Stable outcomes, reuse evidence, lower marginal effort, governed versions, enablement |

Before L3, confirm at minimum:

- Business owner, technical/run owner, support route, and user training are named.
- Identity, least privilege, data minimization/retention, access review, audit logging, and applicable controls are verified.
- Evaluation covers ordinary, edge, adversarial/disallowed, and failure/fallback behavior proportional to consequence.
- Quality, latency, cost, availability, and business impact can be observed; alert thresholds and escalation are agreed.
- Human override, safe degradation, rollback/disable path, and incident response are tested or rehearsed.
- Real users accept the workflow and an owner agrees to monitor adoption and outcomes after handoff.

Do not represent an L1 demo as an L3 system. For high-consequence actions, narrow autonomy and require human approval until evidence and controls justify more.

## Stage 6 — Adopt, operate, and expand

- Embed the capability in the real workflow, not only in a showcase or optional side tool. Address role, training, incentives, and process changes needed for continued use.
- Compare results with the pre-engagement baseline using the agreed window. Separate technical performance from adoption and business outcomes.
- Review usage, task completion, escalation/override, failures, quality, latency/cost, user feedback, and support burden. Investigate declining use; logins alone are not success.
- Expand only when the current slice is stable, users adopt it, the business owner sees value, and the next scope has an owner and safeguards. Seed an adjacent opportunity early without promising it as part of the first proof.
- Plan handover/self-service: documentation, access/ownership transfer, support path, change process, and end date for temporary FDE-intensive support.

## Stage 7 — Distill and scale learning

Close two learning loops:

**For the customer:** turn tacit process knowledge into customer-owned workflow definitions, knowledge, rules, Skills, operating guidance, or applications as authorized.

**For the delivery organization:** propose de-identified, generalizable improvements to a Skill, connector, template, evaluation set, product backlog, or lightweight domain model. De-identification alone does not grant reuse rights: verify contract terms, IP/licensing, confidentiality duties, and any required customer authorization before cross-engagement reuse. Never copy customer records, secrets, unique parameters, or restricted materials into a shared asset.

Classify each candidate:

- **Reusable now:** supported by evidence, broadly applicable, safe to share, and has an owner and regression checks.
- **Needs more evidence:** plausible pattern; keep as a private hypothesis until repeated or reviewed.
- **Customer-specific:** retain only in the authorized customer boundary or contract scope.
- **Do not retain:** sensitive, unlicensed, unsafe, unsupported, or no longer relevant.

Use a monthly or otherwise explicit review/release cadence; capture version, rationale, evidence, compatibility, limits, and rollback. Check whether the next similar engagement needs less discovery/build effort. If effort stays flat, the abstraction or asset strategy is not working.

**Closeout:** Record outcome versus baseline, adoption, operational status, unresolved risks, reusable learning, customer-specific handoff, and next decision. A retrospective should change a process, asset, or decision rule—not merely retell the project.

## Roles and collaboration

Roles are capabilities, not mandatory job titles. One person may cover several in a small team, but accountability must stay explicit.

| Role | Primary accountability |
|---|---|
| Customer sponsor/business owner | Priority, business outcome, process decisions, adoption, and acceptance |
| Echo / domain lead | Problem definition, industry/workflow understanding, value hypothesis, stakeholder trust, generalization judgment |
| Delta / technical lead | Prototype, integration, evaluation, secure engineering, production readiness, technical handoff |
| FDPM / engagement lead | Scope, decisions, schedule, customer expectations, acceptance coordination, feedback quality |
| Customer IT/data/control owners | Authorized access, system/data truth, security/privacy/compliance constraints, production operations |
| Product/asset steward | Triage field feedback, maintain reusable Skills/templates/connectors/evals, versioning and adoption |
| Partner/ISV | Replicate validated playbooks within certification, data, quality, and escalation boundaries |

Use an Echo+Delta pairing for ambiguous/high-value work, add an FDPM when coordination is substantial, and involve customer domain and control owners early. Avoid handoff gaps: customer and technical leads share an outcome and review it together.

## Measure value and leverage

Choose a small set with a baseline, owner, source, and review cadence. Do not present activity counts as outcomes.

- **Business:** cycle time, completion/quality, errors or rework, conversion, service level, cost avoided, revenue, or another workflow-specific outcome.
- **Adoption:** eligible-user activation, repeat use, task completion, abandonment, user confidence, training, and process embedding.
- **Technical/operational:** evaluation quality, groundedness where relevant, escalation/override, latency, cost per successful task, availability, incidents, and recovery.
- **FDE leverage:** delivery effort by stage, verified reuse, time to onboard a new FDE/partner, feedback accepted and used, product/Skill pull-through, and effort trend for comparable engagements.
- **Commercial/portfolio:** retention/expansion and delivery margin only when definitions are reliable and customer/contract permission permits their use.

For each metric, write definition, baseline, target or decision threshold, observation window, attribution limits, and verifier. Technical quality without adoption is not business success; a one-off delivery without learning may be valid bespoke work, but is not scalable FDE.

## BMAD-method inspiration

This playbook adapts the modular, risk-scaled planning and delivery structure of the official [BMAD-METHOD repository](https://github.com/bmad-code-org/BMAD-METHOD): choose depth to fit the work, use durable artifacts as handoff contracts, build in small verifiable units, review evidence, then capture learning. It does not require BMAD installation, commands, role names, or a specific software stack. Consult upstream for current version-specific details.
