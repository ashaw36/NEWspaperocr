# Source Report: FDE Model, End-to-End

## Source and interpretation

Based on Tencent Research Institute, *2026前线共创双向赋能FDE模式行业观察与实践报告*, public-commercial version 5.0 (July 2026), 83-page PDF. References below use printed pagination; main-body PDF pages are seven pages later. The report combines public materials, hiring samples, interviews, and Tencent Cloud practice observations. Treat it as an industry framework, not a universal standard.

Chapter 9's ERP journey is explicitly fictional. Its time spans, customer counts, hours, costs, savings, internal settlement fees, and break-even estimates are scenario assumptions, not validated benchmarks or required thresholds. Hiring/salary data are dated samples with stated limitations. Never turn them into promises or defaults.

## The central model

The report frames FDE (Forward Deployed Engineer) as a **front-line learning and delivery model**, not simply a job title, onsite engineer, or customization service. FDE enters a real business workflow, determines which problem is worth solving, turns model/platform capability into a working outcome, and returns field learning to product/platform teams. The decisive difference from ordinary bespoke delivery is whether experience becomes safe, usable assets that make a comparable next engagement easier.

It defines complementary capabilities:

- **Echo — what to do:** industry and workflow understanding, problem reframing, value judgment, stakeholder trust, and deciding what can generalize.
- **Delta — how to make it work:** prototyping, system integration, model/workflow iteration, evaluation, secure engineering, and productionization.
- **FDPM / engagement lead:** customer communication, scope, requirements, test cases, progress, and expectation alignment. This may be a separate role or explicitly shared.

Echo and Delta may start in one person, but need clear accountability and compatible incentives. A successful team connects field delivery to product/platform work instead of relying on informal feedback.

## Two directions of distillation

1. **For the customer:** extract employee know-how, process rules, and exceptions into customer-owned knowledge, SOPs, workflows, Skills, and applications so the business can operate more consistently.
2. **For the provider/product:** abstract industry-level concepts, common integrations, evaluation methods, workflow patterns, and failure learnings into reviewed Skills, templates, connectors, test sets, and product capabilities.

The boundary is critical: generalize the business concept, not another customer's records, secrets, unique parameters, or restricted code. The report uses a domain semantic layer (ontology) to unify objects, relationships, states, and actions. It cautions that a full ontology is expensive; a practical progression is terminology/scenario lists, then repeated Skills, templates, and connectors, and deeper domain modeling only when evidence and repeat demand justify it.

## From prototype to operation

A runnable demo is an early risk probe, not the end product. Production exposes data quality, integrations, workflow exceptions, permissions, audit, safety, user adoption, and outcome attribution. The report's “80/95/99” framing illustrates why the reliability gap matters; it is not a universal success metric. It recommends representative/historical cases, evaluation and A/B comparison, business baselines, and human fallback instead of expecting 100% autonomous coverage.

Its L0–L4 maturity ladder:

- **L0 Opportunity:** assess workflow, value, and AI feasibility.
- **L1 Prototype:** runnable core path proves possibility.
- **L2 Pilot:** bounded group uses it in a real workflow.
- **L3 Production:** live data/integrations, exceptions, permissions, audit, monitoring, training, rollback, ownership, and service expectations are addressed.
- **L4 Scale:** reusable assets and partner/self-service capabilities support more workflows or customers.

The report notes that efforts often stall between prototype and production because trial users have no operating incentive, data issues were hidden, or approval/compliance paths were postponed. Discover and test these early.

## Chapter 9 cross-engagement flywheel

The fictional ERP illustration has five learning states. Use these as concepts, not a calendar or client-count recipe:

1. **Bootstrap:** experts draft a minimum domain model from prior designs/schemas; AI may suggest entities and relations, but domain experts confirm. Publish a version, readable guide, and known-gap list; do not wait for completeness.
2. **First field use:** Delta decides whether the baseline helps, adapts only what is needed, delivers a customer-specific slice, and files structured gap feedback with a generality hypothesis.
3. **Repeated validation:** Echo reviews feedback on a cadence, separates shared paths from optional extensions, and asks for more evidence on uncertain patterns. Delta starts from the reusable baseline, not zero.
4. **Stabilize and distribute:** comparable deployments show lower effort/faster onboarding; validated assets become templates and tests; partners may replicate with training and quality controls.
5. **Productize and move on:** mature assets need maintenance, not constant reinvention. Serve the proven vertical more lightly; invest in another only when economics justify it.

The report's fictional case proposes internal chargeback/feedback credits and dual delivery/asset KPIs to motivate field and platform teams. These are options, not mandatory mechanisms. The durable principle: field feedback has an owner, review loop, visible adoption, and career/financial credit.

## Additional operating lessons

- **Qualify for value and repeatability:** high business criticality, complex workflows, meaningful data/regulatory constraints, and repeated industry patterns can justify deeper FDE. Simple integrations or unrelated low-value customers may be better served by standard products or partners.
- **Land, then expand:** start with an important, measurable workflow and real users; embed adoption in the business; expand only after sustained value is shown.
- **Measure outcome and leverage:** report business impact and adoption alongside reliability, effort per delivery, reuse, feedback accepted, and whether product capabilities reduce effort for similar work.
- **Organization:** product/platform must stay connected to the field; delivery must have customer access; incentives should value both customer outcomes and knowledge actually reused. Do not make front-line work an unrecognized stepping-stone role.
- **Scale through ecosystem:** validate with provider-led reference engagements; then give reviewed playbooks to capable partners; let customers gain self-service where safe. Keep quality and escalation boundaries clear.
- **Train through projects:** supervised real work, staged responsibility, review, and evidence matter more than classroom attendance alone. Test candidates with ambiguous customer scenarios, not vocabulary quizzes.
- **AI shifts effort, not accountability:** code and first-draft documentation become cheaper; judgment, domain understanding, stakeholder trust, safety, and review of generated output remain human responsibilities.

## Case examples and what they illustrate

- **Palantir:** its ontology connects business objects and allowed actions to AI; FDEs use the product foundation for applications and return gaps to the platform. Transfer the product-leverage mechanism, not a proprietary stack wholesale.
- **Education workcamps:** start with teachers' real tasks, co-build an application, validate in teaching/research practice, then convert repeated needs into Skills and industry products.
- **Media with an ISV:** prioritize value-dense workflow steps, connect content systems, pair Echo's industry framing with Delta's live prototype, and reuse the resulting workflows.
- **Customer success/developer tools:** combine leadership awareness and organizational adoption (Echo), practical prototyping (Delta), evaluation, reusable assets, and continued-use economics. Training alone is not adoption.

## Talent and market appendix

The report's role profile spans engineering/data/API/cloud/LLM skills; product/system judgment such as architecture, evaluation, access control, and safe packaging; and customer-facing skills such as discovery, ambiguity tolerance, stakeholder coordination, and business judgment. It identifies multiple related job titles, so FDE is a capability set rather than a uniform market job description. The overseas and domestic hiring appendix is a snapshot with sample and salary-definition caveats; it supports the qualitative role profile, not current hiring or compensation decisions.

## Page guide

| Report pages | Use in this skill |
|---|---|
| 2–6 | Positioning, executive findings, scope and limits |
| 1–6 | AI adoption gap and demo-to-production challenge |
| 7–11 | FDE definition, Echo/Delta, distillation, assets, scalability tests |
| 12–16 | Palantir, ontology, product feedback, adaptation limits |
| 17–20 | AI cost shifts, Skills/connectors/knowledge, gradual domain modeling |
| 21–24 | FDE/FDPM pairing, field work, Land-and-Expand, L0–L4 |
| 25–30 | Platform/industry examples, workcamps, partner scaling, customer success |
| 31–34 | Failure loops, organization, margin, fit and risks |
| 35–39 | Capability model, training, certification, incentives, team formations |
| 40–50 | Fictional ERP case and mechanisms; apply caveats above |
| 51–57 | Future roles, ecosystem, research method, terminology |
| 58–73 | Hiring/skills/pay sample and job examples; dated context only |
| 74–75 | References and closing statement |
